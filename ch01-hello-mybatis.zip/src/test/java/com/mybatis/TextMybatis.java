package com.mybatis;

import com.mybatis.Student.StudentDao;
import com.project.Student;
import com.template.MybatisUtile;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.io.IOException;
import java.util.List;

public class TextMybatis {
    @Test

    public void textSelectStudents() throws IOException {
        SqlSession sqlSession= MybatisUtile.getSqlSession();
        StudentDao dao =sqlSession.getMapper(StudentDao.class);
        List<Student> students=dao.selectStudent();
        for (Student stu:students){
            System.out.println("学生="+stu);
        }
    }
}
