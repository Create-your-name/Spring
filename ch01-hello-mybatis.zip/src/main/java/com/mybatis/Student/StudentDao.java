package com.mybatis.Student;

import com.project.Student;

import java.util.List;

public interface StudentDao {
    public List<Student> selectStudent();
/*    public int  insertStudent();*/
}
