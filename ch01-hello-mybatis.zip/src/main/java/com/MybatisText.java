package com;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import com.project.Student;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class MybatisText {
    public static void main(String[] args) throws IOException {
        String config ="mybatis.xml";
        InputStream in =Resources.getResourceAsStream(config);
        SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
        SqlSessionFactory factory = builder.build(in);
        SqlSession sqlSession = factory.openSession();
        String sqlid = "com.mybatisStudentDao.StudentDao.selectStudent";
        List<Student> studentList = sqlSession.selectList(sqlid);
        studentList.forEach((student) -> {
            System.out.println(student);
        });

      /*  String sqlid2 = "a.c";
        Student student2 =new Student();
        student2.setId(1005);
        student2.setName("刘海大帅逼");
        student2.setAge(18);
        int nums =sqlSession.insert(sqlid2,student2);
        //提交事务操作
        sqlSession.commit();
*/

        sqlSession.close();
    }
}
